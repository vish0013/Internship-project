// export const SERVER_URL = 'http://localhost:8081/';
// export const ROLL_NUMBER = '1805096';
// http://localhost:8080/AI-Enabled_FinTech_B2B_Invoice_system/DataRetrieval
// export const SERVER_URL = 'localhost:8080/hrc/api/load';
export const SERVER_URL =
    " http://localhost:8080/AI-Enabled_FinTech_B2B_Invoice_system/DataRetrieval";
export const ROLL_NUMBER = "123";
